package com.example.shack;

import android.os.Bundle;
import android.app.Activity;
import android.app.TabActivity;
import android.content.Intent;
import android.view.Menu;
import android.widget.TabHost;
import android.widget.TabHost.TabSpec;

public class SecondHome extends TabActivity {
	TabHost tabhost;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_second_home);
		
		tabhost = (TabHost) findViewById(android.R.id.tabhost);
		TabSpec spec = tabhost.newTabSpec("Tip 1");
		spec.setContent(new Intent(this, Applications.class));
		spec.setIndicator("Application");
		tabhost.addTab(spec);
		
		TabSpec spec2 = tabhost.newTabSpec("Tip 2");
		spec2.setContent(new Intent(this, Devices.class));
		spec2.setIndicator("Devices");
		tabhost.addTab(spec2);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.second_home, menu);
		return true;
	}

}
