package com.example.shack;

import android.net.Uri;
import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;

public class StudentApplication extends Activity {
	
	ImageView office, plag, chegg, dropbox;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_student_application);
		getoffice();
		getplag();
		//getChegg();
		getDropbox();
		
	}

	private void getDropbox() {
		// TODO Auto-generated method stub
		dropbox = (ImageView)findViewById(R.id.imagedrop);
		dropbox.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent dropIntent= new Intent(Intent.ACTION_VIEW,
						 Uri.parse("http://www.google.com/dropbox download"));
				startActivity(dropIntent);
			}
		});
	}

/*	private void getChegg() {
		// TODO Auto-generated method stub
		 = (ImageView)findViewById(R.id.imagechegg);
		chegg.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent cheggIntent= new Intent(Intent.ACTION_VIEW,
						 Uri.parse("http://www.google.com/chegg downoad"));
				startActivity(cheggIntent);
			}
		});
	}*/

	private void getplag() {
		// TODO Auto-generated method stub
		plag = (ImageView)findViewById(R.id.imageplag);
		plag.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent plagIntent= new Intent(Intent.ACTION_VIEW,
						 Uri.parse("http://www.google.com/plag Tracker"));
				startActivity(plagIntent);
			}
		});
	}

	private void getoffice() {
		// TODO Auto-generated method stub
		office= (ImageView)findViewById(R.id.imageoffice);
		office.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent officeIntent= new Intent(Intent.ACTION_VIEW,
						 Uri.parse("http://www.google.com/ms office"));
				startActivity(officeIntent);
			}
		});
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.student_application, menu);
		return true;
	}

}
