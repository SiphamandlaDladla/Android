package com.example.shack;

import android.net.Uri;
import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;

public class KidsApplications extends Activity {
	
	ImageView elmo, type, vocab, words;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_kids_applications);
		getElmo();
		getType();
		getVocab();
		getWords();

	}
		
		private void getElmo() {
			// TODO Auto-generated method stub
			elmo = (ImageView)findViewById(R.id.imageElmo);
			elmo.setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					Intent elmIntent= new Intent(Intent.ACTION_VIEW,
							 Uri.parse("http://www.google.com/elmo loves 123s"));
					startActivity(elmIntent);
				}
			});
		}

		private void getWords() {
			// TODO Auto-generated method stub
			words = (ImageView)findViewById(R.id.imageWord);
			words.setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					Intent wrdIntent= new Intent(Intent.ACTION_VIEW,
							 Uri.parse("http://www.google.com/my first 101 words"));
					startActivity(wrdIntent);
				}
			});
		}

		private void getType() {
			// TODO Auto-generated method stub
			type = (ImageView)findViewById(R.id.imageType);
			type.setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					Intent typIntent= new Intent(Intent.ACTION_VIEW,
							 Uri.parse("http://www.google.com/spongebob typing game"));
					startActivity(typIntent);
				}
			});
		}

		private void getVocab() {
			// TODO Auto-generated method stub
			vocab = (ImageView)findViewById(R.id.imageVocab);
			vocab.setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					Intent vocIntent= new Intent(Intent.ACTION_VIEW,
							 Uri.parse("http://www.google.com/kids vocab mindsnacks"));
					startActivity(vocIntent);
				}
			});
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.kids_applications, menu);
		return true;
	}

}
