package com.example.shack;

import android.net.Uri;
import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;

public class ProfessionalApplications extends Activity {
	
	ImageView meet, note, register, cloud, audio;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_professional_applications);
		getMeet();
		getNote();
		getRegister();
		getCloud();
		getAudio();
	}

	private void getRegister() {
		// TODO Auto-generated method stub
		register = (ImageView)findViewById(R.id.imageRegister);
		register.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent regIntent= new Intent(Intent.ACTION_VIEW,
						 Uri.parse("http://www.google.com/square register app"));
				startActivity(regIntent);
			}
		});
	}

		private void getMeet() {
			// TODO Auto-generated method stub
			meet = (ImageView)findViewById(R.id.imageMeet);
			meet.setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					Intent mtIntent= new Intent(Intent.ACTION_VIEW,
							 Uri.parse("http://www.google.com/gotomeeting app"));
					startActivity(mtIntent);
				}
			});
		}

		private void getNote() {
			// TODO Auto-generated method stub
			note = (ImageView)findViewById(R.id.imagenote);
			note.setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					Intent ntIntent= new Intent(Intent.ACTION_VIEW,
							 Uri.parse("http://www.google.com/evernote app"));
					startActivity(ntIntent);
				}
			});
		}

		private void getCloud() {
			// TODO Auto-generated method stub
			cloud = (ImageView)findViewById(R.id.imagecloud);
			cloud.setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					Intent cldIntent= new Intent(Intent.ACTION_VIEW,
							 Uri.parse("http://www.google.com/cloudon app"));
					startActivity(cldIntent);
				}
			});
		}

		private void getAudio() {
			// TODO Auto-generated method stub
			audio = (ImageView)findViewById(R.id.imageAudio);
			audio.setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					Intent audIntent= new Intent(Intent.ACTION_VIEW,
							 Uri.parse("http://www.google.com/audio memos"));
					startActivity(audIntent);
				}
			});
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.professional_applications, menu);
		return true;
	}

}
