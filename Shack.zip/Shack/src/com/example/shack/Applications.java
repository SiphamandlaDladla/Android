package com.example.shack;

import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class Applications extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_applications);
		
		Button btnAppStud = (Button)findViewById(R.id.btnApp);
		Button btnCorpStud = (Button)findViewById(R.id.btnCorp);
		Button btnEdu = (Button)findViewById(R.id.btnEdu);
		Button btnEntrtain = (Button)findViewById(R.id.btnEntertain);
		
btnAppStud.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				Intent i = new Intent(arg0.getContext(), StudentApplication.class);
				startActivity(i);
			}
		});
		
		btnCorpStud.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg1) {
				// TODO Auto-generated method stub
				Intent x = new Intent(arg1.getContext(), ProfessionalApplications.class);
				startActivity(x);
			}
		});
		
		btnEdu.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg2) {
				// TODO Auto-generated method stub
				Intent y = new Intent(arg2.getContext(), KidsApplications.class);
				startActivity(y);
			}
		});
		
		btnEntrtain.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg3) {
				// TODO Auto-generated method stub
				Intent z = new Intent(arg3.getContext(), EntertainmentApplications.class);
				startActivity(z);
			}
		});
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.applications, menu);
		return true;
	}

}
