package com.example.shack;

import android.net.Uri;
import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;

public class EntertainmentDevice extends Activity {
	
	ImageView dj, speaker, tv, box, tvn;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_entertainment_device);
		getDj();
		getSpeak();
		getTv();
		getBox();
		getTvN();
	}
		
		private void getTv() {
			// TODO Auto-generated method stub
			tv= (ImageView)findViewById(R.id.imageTv);
			tv.setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					Intent tvIntent= new Intent(Intent.ACTION_VIEW,
							 Uri.parse("http://www.google.com/samsung htd5550"));
					startActivity(tvIntent);
				}
			});
		}

		private void getTvN() {
			// TODO Auto-generated method stub
			tvn = (ImageView)findViewById(R.id.consoleId);
			tvn.setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					Intent tvnIntent= new Intent(Intent.ACTION_VIEW,
							 Uri.parse("http://www.google.com/sony hmz t2"));
					startActivity(tvnIntent);
				}
			});
		}

		private void getSpeak() {
			// TODO Auto-generated method stub
			speaker = (ImageView)findViewById(R.id.imageSpeaker);
			speaker.setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					Intent spkIntent= new Intent(Intent.ACTION_VIEW,
							 Uri.parse("http://www.google.com/LG 55LM8600"));
					startActivity(spkIntent);
				}
			});
		}

		private void getBox() {
			// TODO Auto-generated method stub
			box = (ImageView)findViewById(R.id.imageBox);
			box.setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					Intent bxIntent= new Intent(Intent.ACTION_VIEW,
							 Uri.parse("http://www.google.com/microsoft xbox 360 kinect"));
					startActivity(bxIntent);
				}
			});
		}

		private void getDj() {
			// TODO Auto-generated method stub
			dj = (ImageView)findViewById(R.id.imageDj);
			dj.setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					Intent djIntent= new Intent(Intent.ACTION_VIEW,
							 Uri.parse("http://www.google.com/philips dj party machine"));
					startActivity(djIntent);
				}
			});
	}
		
		private void getWebI() {
			// TODO Auto-generated method stub
			dj = (ImageView)findViewById(R.id.webId);
			dj.setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					Intent djIntent= new Intent(Intent.ACTION_VIEW,
							 Uri.parse("http://www.google.com/philips dj party machine"));
					startActivity(djIntent);
				}
			});
	}
		
		private void getPsp() {
			// TODO Auto-generated method stub
			dj = (ImageView)findViewById(R.id.pspid);
			dj.setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					Intent djIntent= new Intent(Intent.ACTION_VIEW,
							 Uri.parse("http://www.google.com/philips dj party machine"));
					startActivity(djIntent);
				}
			});
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.entertainment_device, menu);
		return true;
	}

}
