package com.example.shack;

import android.net.Uri;
import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;

public class EntertainmentApplications extends Activity {
	
	ImageView mario;
	ImageView call;
	ImageView tetris;
	ImageView pacman, hitman, tombraider,nsfcarbon;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_entertainment_applications);
		marioDownLoad();
		callDownLoad();
		tetrisDownLoad();
		hitmanDownLoad();
		tombraiderDownLoad();
		nsfDownLoad();
		
	}
		
		private void nsfDownLoad() {
			// TODO Auto-generated method stub
			nsfcarbon= (ImageView)findViewById(R.id.imageneedforspeed);
			nsfcarbon.setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					Intent nsfIntent= new Intent(Intent.ACTION_VIEW,
							 Uri.parse("http://www.google.co.za/search?q=needforspeed+game+download"));
					startActivity(nsfIntent);
				}
			});
		}

		private void tombraiderDownLoad() {
			// TODO Auto-generated method stub
			tombraider= (ImageView)findViewById(R.id.imagetombraider);
			tombraider.setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					Intent tombraiderIntent= new Intent(Intent.ACTION_VIEW,
							 Uri.parse("http://www.google.co.za/search?q=tombraider+game+download"));
					startActivity(tombraiderIntent);
				}
			});
		}

		private void hitmanDownLoad() {
			// TODO Auto-generated method stub
			pacman= (ImageView)findViewById(R.id.imagepacman);
			pacman.setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					Intent hitmanIntent= new Intent(Intent.ACTION_VIEW,
							 Uri.parse("http://www.google.co.za/search?q=hitman+game+download"));
					startActivity(hitmanIntent);
				}
			});
		}

		private void tetrisDownLoad() {
			// TODO Auto-generated method stub
			tetris= (ImageView)findViewById(R.id.imagetetris);
			tetris.setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					
					Intent tetrisIntent= new Intent(Intent.ACTION_VIEW,
							 Uri.parse("http://www.google.co.za/search?q=tetris+game+download"));
					startActivity(tetrisIntent);
					
				}
			});
			
		}

		private void callDownLoad() {
			// TODO Auto-generated method stub
			call= (ImageView)findViewById(R.id.imageCallOfDuty);
			call.setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View arg0) {
					// TODO Auto-generated method stub
					Intent callIntent= new Intent(Intent.ACTION_VIEW,
							Uri.parse("http://www.google.co.za/search?q=callofduty+game+download"));
					startActivity(callIntent);
				}
			});
			
			
		}
		
		private void marioDownLoad() {
			// TODO Auto-generated method stub
			mario= (ImageView) findViewById(R.id.imageMario);
			mario.setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View arg0) {
					// TODO Auto-generated method stub
					
					Intent marioIntent = new Intent(Intent.ACTION_VIEW, 
	    	                Uri.parse("http://www.google.co.za/search?q=mario+game+download")); 
							
							startActivity(marioIntent);
				}
			} );
			
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.entertainment_applications, menu);
		return true;
	}

}
