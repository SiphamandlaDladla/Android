package com.example.shack;

import android.net.Uri;
import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;

public class KidsDevice extends Activity {
	
	ImageView ipad, leap, psp, wii;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_kids_device);
		getIpad();
		getLeap();
		getPsp();
		getWii();
		
	}
		
		private void getWii() {
			// TODO Auto-generated method stub
			wii = (ImageView)findViewById(R.id.imagewii);
			wii.setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					Intent wiiIntent= new Intent(Intent.ACTION_VIEW,
							 Uri.parse("http://www.google.com/nintendo wii"));
					startActivity(wiiIntent);
				}
			});
		}

		private void getPsp() {
			// TODO Auto-generated method stub
			psp = (ImageView)findViewById(R.id.imagepsp);
			psp.setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					Intent pspIntent= new Intent(Intent.ACTION_VIEW,
							 Uri.parse("http://www.google.com/psp"));
					startActivity(pspIntent);
				}
			});
		}

		private void getLeap() {
			// TODO Auto-generated method stub
			leap = (ImageView)findViewById(R.id.imageleap);
			leap.setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					Intent lpIntent= new Intent(Intent.ACTION_VIEW,
							 Uri.parse("http://www.google.com/leappad"));
					startActivity(lpIntent);
				}
			});
		}

		private void getIpad() {
			// TODO Auto-generated method stub
			ipad = (ImageView)findViewById(R.id.imageipad);
			ipad.setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					Intent ipdIntent= new Intent(Intent.ACTION_VIEW,
							 Uri.parse("http://www.google.com/fire hd kids"));
					startActivity(ipdIntent);
				}
			});
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.kids_device, menu);
		return true;
	}

}
