package com.example.shack;

import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class Devices extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_devices);
		
		Button but = (Button)findViewById(R.id.btnStudent);
		Button butPro = (Button)findViewById(R.id.btnPro);
		Button bntKids = (Button)findViewById(R.id.btnKidsEdu);
		Button bntTain = (Button)findViewById(R.id.btnEntertainment);
		
		but.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				Intent i = new Intent(arg0.getContext(), StudentDevice.class);
				startActivity(i);
			}
		});
		
		butPro.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg1) {
				// TODO Auto-generated method stub
				Intent a = new Intent(arg1.getContext(), ProfessionalDevices.class);
				startActivity(a);
			}
		});
		
		bntKids.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg2) {
				// TODO Auto-generated method stub
				Intent b = new Intent(arg2.getContext(), KidsDevice.class);
				startActivity(b);
			}
		});
		
		bntTain.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg3) {
				// TODO Auto-generated method stub
				Intent c = new Intent(arg3.getContext(), EntertainmentDevice.class);
				startActivity(c);
			}
		});
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.devices, menu);
		return true;
	}

}
