package com.example.shack;

import android.net.Uri;
import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;

public class StudentDevice extends Activity {
	
	ImageView watch, tablet, phone, laptop, alarm, cam;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_student_device);
		getWatch();
		getTab();
		getphone();
		getAlarm();
		getLaptop();
		getCamcorder();
	}
		
		private void getCamcorder() {
			// TODO Auto-generated method stub
			cam = (ImageView)findViewById(R.id.imagecamcorder);
			cam.setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					Intent camIntent= new Intent(Intent.ACTION_VIEW,
							 Uri.parse("http://www.google.com/nixon camcorders for students"));
					startActivity(camIntent);
				}
			});
		}

		private void getLaptop() {
			// TODO Auto-generated method stub
			laptop = (ImageView)findViewById(R.id.imagelaptop);
			laptop.setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					Intent laptopIntent= new Intent(Intent.ACTION_VIEW,
							 Uri.parse("http://www.google.com/hp laptops for students"));
					startActivity(laptopIntent);
				}
			});
		}

		private void getAlarm() {
			// TODO Auto-generated method stub
			alarm= (ImageView)findViewById(R.id.imagealarm);
			alarm.setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					Intent alarmIntent= new Intent(Intent.ACTION_VIEW,
							 Uri.parse("http://www.google.com/smart alarm for students"));
					startActivity(alarmIntent);
				}
			});
		}

		private void getphone() {
			// TODO Auto-generated method stub
			phone= (ImageView)findViewById(R.id.imagephone);
			phone.setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					Intent phonetIntent= new Intent(Intent.ACTION_VIEW,
							 Uri.parse("http://www.google.com/android smartphones for students"));
					startActivity(phonetIntent);
				}
			});
		}

		private void getTab() {
			// TODO Auto-generated method stub
			tablet= (ImageView)findViewById(R.id.imagetab);
			tablet.setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					Intent tabletIntent= new Intent(Intent.ACTION_VIEW,
							 Uri.parse("http://www.google.com/healthy smart watch for students"));
					startActivity(tabletIntent);
				}
			});
			
		}

		private void getWatch() {
			// TODO Auto-generated method stub
			watch= (ImageView)findViewById(R.id.imagesmartwatch);
			watch.setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					Intent watchIntent= new Intent(Intent.ACTION_VIEW,
							 Uri.parse("http://www.google.com/healthy smart watch for students"));
					startActivity(watchIntent);
				}
			});
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.student_device, menu);
		return true;
	}

}
