package com.example.shack;

import android.net.Uri;
import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;

public class ProfessionalDevices extends Activity {
	
	ImageView lap, tabs, security, web;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_professional_devices);
		getLap();
		getTabs();
		getSecurity();
		getWeb();
		
	}
		
		private void getWeb() {
			// TODO Auto-generated method stub
			web = (ImageView)findViewById(R.id.imageweb);
			web.setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					Intent wbIntent= new Intent(Intent.ACTION_VIEW,
							 Uri.parse("http://www.google.com/web camera for business"));
					startActivity(wbIntent);
				}
			});
		}

		private void getSecurity() {
			// TODO Auto-generated method stub
			security = (ImageView)findViewById(R.id.imagesec);
			security.setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					Intent secIntent= new Intent(Intent.ACTION_VIEW,
							 Uri.parse("http://www.google.com/security camera for business"));
					startActivity(secIntent);
				}
			});
		}

		private void getTabs() {
			// TODO Auto-generated method stub
			tabs = (ImageView)findViewById(R.id.imagetabs);
			tabs.setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					Intent tbIntent= new Intent(Intent.ACTION_VIEW,
							 Uri.parse("http://www.google.com/tablets for business"));
					startActivity(tbIntent);
				}
			});
		}

		private void getLap() {
			// TODO Auto-generated method stub
			lap = (ImageView)findViewById(R.id.imagelap);
			lap.setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					Intent laptIntent= new Intent(Intent.ACTION_VIEW,
							 Uri.parse("http://www.google.com/laptops for business"));
					startActivity(laptIntent);
				}
			});
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.professional_devices, menu);
		return true;
	}

}
